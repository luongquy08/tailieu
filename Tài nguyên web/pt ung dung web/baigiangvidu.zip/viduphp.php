<html><head><title>PHO examp</title></head>
<body>
<h3>Vi du ve PHP</h3><hr />
<?php
	echo 'PHP example<br />';
	print 'PHP example<br />';
	printf ("PHP example<br />");

	$tenlop = 'K54I';
	$welcome = 'Welcome $tenlop';
	echo $welcome . '<br />';
	$welcome = "Welcome $tenlop";
	echo $welcome . '<br />';
	echo $welcome . ', nam ' . 2016 . '<br />';



?>
</body>
</html>
